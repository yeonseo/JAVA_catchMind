package Model;

public class UserRankingVO {

}
